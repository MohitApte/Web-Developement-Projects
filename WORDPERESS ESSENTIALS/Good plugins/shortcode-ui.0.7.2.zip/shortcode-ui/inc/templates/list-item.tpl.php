<script type="text/html" id="tmpl-add-shortcode-list">

	<ul class="add-shortcode-list"></ul>

</script>

<script type="text/html" id="tmpl-add-shortcode-list-item">

	<div class="add-shortcode-list-item-icon">{{{ data.listItemImage }}}</div>

	<h4 class="add-shortcode-list-item-title">{{ data.label }}</h4>

</script>
