<p>
	<?php
	echo esc_html__(
		'Get your 30% Independence Day discount for BackWPup Pro! Only available until July 5th, 2017.',
		'backwpup'
	);
	?>
</p>
