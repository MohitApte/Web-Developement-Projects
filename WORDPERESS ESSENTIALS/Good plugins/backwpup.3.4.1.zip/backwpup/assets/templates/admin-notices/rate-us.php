<p>
	<?php
	echo esc_html__(
		'Are you happy with BackWPup? If you are satisfied with our free plugin and support, then please make us even happier and just take 30 seconds to leave a positive rating. :) We would really appreciate that and it will motivate our team to develop even more cool features for BackWPup!',
		'backwpup'
	);
	?>
</p>
