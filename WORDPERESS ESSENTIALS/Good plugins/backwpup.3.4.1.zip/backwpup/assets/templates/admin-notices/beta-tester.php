<p>
	<?php
	echo esc_html__(
		'To ensure that our releases are as bug-free as possible, we need you as a beta tester!',
		'backwpup'
	);
	?>
</p>
